create definer = root@localhost trigger trg_soft_delete_child_comments
    after update
    on diary_comments
    for each row
BEGIN
    IF NEW.is_deleted = 1 THEN
        UPDATE diary_comments
        SET is_deleted = 1
        WHERE parent_id = NEW.comment_id;
    END IF;
END;

