create definer = root@localhost trigger trg_set_updated_at_on_update
    before update
    on diary_entries
    for each row
BEGIN
    SET NEW.diary_updated_at = NOW();
END;

