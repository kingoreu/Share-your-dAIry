create definer = root@localhost trigger trg_delete_analysis_with_entry
    after delete
    on diary_entries
    for each row
BEGIN
    DELETE FROM diary_analysis WHERE entry_id = OLD.entry_id;
END;

