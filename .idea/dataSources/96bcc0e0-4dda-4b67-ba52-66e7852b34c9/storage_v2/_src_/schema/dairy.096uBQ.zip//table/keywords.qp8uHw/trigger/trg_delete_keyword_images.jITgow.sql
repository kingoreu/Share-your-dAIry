create definer = root@localhost trigger trg_delete_keyword_images
    after delete
    on keywords
    for each row
BEGIN
    DELETE FROM keyword_images WHERE keyword_id = OLD.keyword_id;
END;

