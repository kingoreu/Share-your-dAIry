create definer = root@localhost trigger trg_shared_diary_member_no_dup
    before insert
    on shared_diary_members
    for each row
BEGIN
    IF EXISTS (
        SELECT 1 FROM shared_diary_members
        WHERE shared_diary_id = NEW.shared_diary_id
          AND user_id = NEW.user_id
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Member already exists in this shared diary';
    END IF;
END;

